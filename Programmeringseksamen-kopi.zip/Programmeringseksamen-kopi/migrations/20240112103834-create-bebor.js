'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Bebor', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      nr: {
        type: Sequelize.STRING
      },
      dato: {
        type: Sequelize.DATE
      },
      lejersNavn: {
        type: Sequelize.STRING
      },
      lejersAdresse: {
        type: Sequelize.STRING
      },
      lejersTelefon: {
        type: Sequelize.STRING
      },
      problem: {
        type: Sequelize.STRING
      },
      ordnet: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Bebor');
  }
};