'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Bebor', [{
      nr: '123',
      dato: new Date(),
      lejersNavn: 'Henrik Hansen',
      lejersAdresse: 'bollebobvej 1',
      lejersTelefon: '1234567890',
      problem: 'ødelagt vaskemaskine',
      ordnet: 'ja',
      createdAt: new Date(),
      updatedAt: new Date()
    }], {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Bebor', null, {});
  }
};