const express = require('express');
const path = require('path');
const db = require('./models'); // Tilføj denne linje
const app = express();


// Serveren skal tjene statiske filer fra 'public' mappen
app.use(express.static(path.join(__dirname, 'public')));

// Endpoint for index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Endpoint for Oversigt1.html
app.get('/oversigt1', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'oversigt1.html'));
});

// Endpoint for Oversigt2.html
app.get('/oversigt2', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'oversigt2.html'));
});

// Start serveren
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Serveren kører på http://localhost:${port}`));

app.get('/api/bebor', async (req, res) => {
    const bebor = await db.Bebor.findAll();
    res.json(bebor);
});
app.get('/Indberet.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Indberet.html'));
  });

const Bebor = require('./models/bebor');

app.post('/api/report', async (req, res) => {
  try {
    const bebor = await Bebor.create({
      dato: req.body.dato,
      lejersNavn: req.body.lejersNavn,
      lejersAdresse: req.body.lejersAdresse,
      lejersTelefon: req.body.lejersTelefon,
      problem: req.body.problem
    });
    res.status(201).json(bebor);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post('/api/report', async (req, res) => {
    try {
      const bebor = await Bebor.create({
        dato: req.body.dato,
        lejersNavn: req.body.lejersNavn,
        lejersAdresse: req.body.lejersAdresse,
        lejersTelefon: req.body.lejersTelefon,
        problem: req.body.problem
      });
      res.status(201).json(bebor);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });