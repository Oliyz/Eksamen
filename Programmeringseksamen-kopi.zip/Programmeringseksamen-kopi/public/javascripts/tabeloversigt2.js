// JavaScript
let books = [
    {nr: 1, dato: '2021-01-01', navn: 'Lejer 1', adresse: 'Adresse 1', telefon: '12345678', problem: 'Problem 1', ordnet: 'Ja'},
    {nr: 2, dato: '2021-02-01', navn: 'Lejer 2', adresse: 'Adresse 2', telefon: '23456789', problem: 'Problem 2', ordnet: 'Nej'},
    {nr: 3, dato: '2021-03-01', navn: 'Lejer 3', adresse: 'Adresse 3', telefon: '34567890', problem: 'Problem 3', ordnet: 'Ja'},
];
let table = document.querySelector("table");

for (let book of books) {
    let row = document.createElement("tr");

    for (let key in book) {
        let cell = document.createElement("td");
        cell.textContent = book[key];
        row.appendChild(cell);
    }

    table.appendChild(row);
}